
import { renderizar } from './render.js';
import { propiedades_alquiler } from './data-alquiler.js';
renderizar(propiedades_alquiler, '#grid-alquiler');
