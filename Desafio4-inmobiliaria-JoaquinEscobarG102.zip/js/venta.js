
import { renderizar } from './render.js';
import { propiedades_venta } from './data-venta.js';
renderizar(propiedades_venta, '#grid-venta');
